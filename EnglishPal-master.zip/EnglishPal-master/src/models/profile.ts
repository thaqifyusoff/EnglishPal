export interface Profile {
    username: string;
    fullname: string;
    phonenumber: string;
    type: string;
    level: number;




}